# NAIJASEC WEB CTF v1
A web based Capture The Flag hacking contest intended for Naija Sec CTF.
  
This CTF is web based. That means you will be facing web challanges along with other minor challanges to get the flag. Since this is intended for beginners, the difficulty level has been kept easy.

## Setup
Build and start the application with Docker.
```bash
docker build -t naijasec .
docker run --rm -p 3000:80 naijasec
```

You should now be able to reach the application on http://localhost:3000

## Skills this CTF teaches:
* Identifying loopholes
* Source code inspection
* Decoding obfuscated code
* Directory bruteforcing
* Relating different situations
* Basic Image stegnography

Hints

<h2>ALERT! SPOILER AHEAD!</h2>

Phase 1: Rabbithole<br>
Phase 2: Find that special directory<br>
Phase 3: Even an innocent looking page might be hiding something in the source.<br>
Phase 4: Ever heard about Javascrip Obfuscation and base64? Go learn about it!<br>
Phase 5: Find the door that requires THAT KEY.<br>
Phase 6: Find how to see the metadata inside an image, specially comments.<br>
